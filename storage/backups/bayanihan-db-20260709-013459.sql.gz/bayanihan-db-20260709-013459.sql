--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'WIN1252';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: block_audit_log_modification(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.block_audit_log_modification() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
            BEGIN
                IF current_setting('app.allow_audit_mutations', true) = 'true' THEN
                    IF TG_OP = 'DELETE' THEN
                        RETURN OLD;
                    END IF;
                    RETURN NEW;
                END IF;
                RAISE EXCEPTION 'audit_logs are append-only: cannot modify or delete rows';
            END;
            $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agencies (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    short character varying(255),
    slug character varying(255),
    description text,
    contact_info character varying(255),
    map_link text,
    logo_url text,
    location_query text,
    is_active boolean DEFAULT true NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    latitude numeric(10,7),
    longitude numeric(10,7),
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    action character varying(50) NOT NULL,
    module character varying(255) NOT NULL,
    entity_id uuid,
    description text,
    old_value jsonb,
    new_value jsonb,
    user_id uuid,
    "timestamp" timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    ip_address character varying(45),
    user_agent text,
    request_id uuid,
    prev_hash character varying(64),
    CONSTRAINT audit_logs_action_check CHECK (((action)::text = ANY (ARRAY['CREATE'::text, 'UPDATE'::text, 'DELETE'::text, 'LOGIN'::text, 'LOGOUT'::text, 'ARCHIVE'::text, 'UNARCHIVE'::text, 'PUBLISH'::text])))
);


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration bigint NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration bigint NOT NULL
);


--
-- Name: case_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_categories (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    color character varying(7),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: case_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_documents (
    id uuid NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_type character varying(50),
    size bigint,
    case_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: case_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_issues (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: case_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_notifications (
    id uuid NOT NULL,
    case_id uuid NOT NULL,
    client_email character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    data json,
    related_url character varying(255),
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: case_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_statuses (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    color character varying(7),
    sort_order integer DEFAULT 0 NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases (
    id uuid NOT NULL,
    case_number character varying(255) NOT NULL,
    client_type character varying(20) NOT NULL,
    vulnerability_indicator character varying(255),
    nok_vulnerability_indicator character varying(255),
    tracker_number character varying(255) NOT NULL,
    summary text,
    status character varying(50) DEFAULT 'OPEN'::character varying NOT NULL,
    closed_at timestamp(0) without time zone,
    consent_given_at timestamp(0) without time zone,
    user_id uuid NOT NULL,
    client_id uuid,
    category_id uuid,
    case_issue_id uuid,
    draft_client_data jsonb,
    escalation_reason character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: client_addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_addresses (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    region character varying(255),
    province character varying(255),
    city_municipality character varying(255),
    barangay character varying(255),
    street text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: client_employments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_employments (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    employer_name text,
    "position" text,
    last_position text,
    country text,
    last_country text,
    start_date date,
    end_date date,
    date_of_arrival date,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    middle_initial character varying(1),
    suffix character varying(255),
    date_of_birth text,
    sex character varying(10),
    email character varying(255),
    contact_number character varying(255),
    avatar_url character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    CONSTRAINT clients_sex_check CHECK (((sex IS NULL) OR ((sex)::text = ANY ((ARRAY['MALE'::character varying, 'FEMALE'::character varying])::text[]))))
);


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id uuid NOT NULL,
    to_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    mailable_type character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    job_uuid uuid,
    error_message text,
    sent_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id uuid NOT NULL,
    case_id uuid NOT NULL,
    agency_id uuid,
    referral_id uuid,
    service_name character varying(255),
    overall_rating integer,
    comments text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: feedback_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback_invitations (
    id uuid NOT NULL,
    case_id uuid NOT NULL,
    agency_id uuid NOT NULL,
    referral_id uuid NOT NULL,
    client_email character varying(255),
    token_prefix character varying(16) NOT NULL,
    token_hash character varying(64) NOT NULL,
    service_name character varying(255),
    snapshot_source character varying(32) DEFAULT 'agency_active_form'::character varying NOT NULL,
    form_snapshot json NOT NULL,
    rating_labels json NOT NULL,
    expires_at timestamp(0) without time zone NOT NULL,
    submitted_at timestamp(0) without time zone,
    used_feedback_id uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: feedback_servqual_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback_servqual_responses (
    id uuid NOT NULL,
    feedback_id uuid NOT NULL,
    question_id character varying(255) NOT NULL,
    question_text text NOT NULL,
    dimension character varying(255) NOT NULL,
    expectation integer,
    perception integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: milestones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.milestones (
    id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    refr_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: next_of_kin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.next_of_kin (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    middle_initial character varying(1),
    relationship character varying(255),
    is_primary boolean DEFAULT false NOT NULL,
    phone_number text,
    email text,
    full_address text,
    region character varying(255),
    province character varying(255),
    city_municipality character varying(255),
    barangay character varying(255),
    street text,
    sort_order integer DEFAULT 0,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    type character varying(255) NOT NULL,
    notifiable_id uuid NOT NULL,
    notifiable_type character varying(255) NOT NULL,
    data text NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: referral_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referral_attachments (
    id uuid NOT NULL,
    referral_id uuid NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_type character varying(50),
    size bigint,
    user_id uuid,
    replaces_id uuid,
    version_group_id uuid,
    is_archived boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: referral_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referral_comments (
    id uuid NOT NULL,
    refr_id uuid NOT NULL,
    parent_id uuid,
    content text NOT NULL,
    visibility character varying(50) NOT NULL,
    is_edited boolean DEFAULT false NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: referral_compliance_requirements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referral_compliance_requirements (
    id uuid NOT NULL,
    referral_id uuid NOT NULL,
    service_name character varying(255) NOT NULL,
    requirement_name character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    fulfilled_by uuid,
    completed_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid
);


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referrals (
    id uuid NOT NULL,
    required_services text NOT NULL,
    notes text,
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    decision character varying(20),
    decision_comment text,
    case_id uuid NOT NULL,
    agcy_id uuid NOT NULL,
    first_action_at timestamp(0) without time zone,
    referral_assigned_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    CONSTRAINT referrals_decision_check CHECK (((decision IS NULL) OR ((decision)::text = ANY ((ARRAY['ACCEPT'::character varying, 'REJECT'::character varying])::text[]))))
);


--
-- Name: service_requirements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_requirements (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_required boolean NOT NULL,
    service_id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    agcy_id uuid,
    processing_days integer,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT services_processing_days_check CHECK (((processing_days IS NULL) OR ((processing_days >= 0) AND (processing_days <= 365))))
);


--
-- Name: servqual_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.servqual_configs (
    id uuid NOT NULL,
    agency_id uuid NOT NULL,
    service_name character varying(255) NOT NULL,
    questions json NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    is_active boolean DEFAULT false NOT NULL,
    activated_at timestamp(0) without time zone
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id uuid,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying(255) NOT NULL,
    category character varying(255),
    value text,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    agcy_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    contact_number character varying(255),
    avatar_url text,
    "position" character varying(255),
    department character varying(255),
    office_location character varying(255),
    bio text,
    emergency_contact text,
    timezone character varying(255) DEFAULT 'Asia/Manila'::character varying,
    mfa_secret text,
    mfa_recovery_codes json,
    mfa_enabled_at timestamp(0) without time zone,
    notifications_config json,
    onboarding_completed_at timestamp(0) without time zone,
    onboarding_step character varying(100),
    profile_completed_at timestamp(0) without time zone,
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(0) without time zone,
    deleted_by uuid,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: agencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agencies (id, name, short, slug, description, contact_info, map_link, logo_url, location_query, is_active, is_default, latitude, longitude, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, action, module, entity_id, description, old_value, new_value, user_id, "timestamp", is_deleted, deleted_at, deleted_by, ip_address, user_agent, request_id, prev_hash) FROM stdin;
fdedbc3d-dd7c-422c-90ee-b6a774194223	CREATE	user	2c090aca-d491-42c8-858e-0d474514e356	Elmira Nicolas III registered as Case Manager	\N	{"name": "Elmira Nicolas III", "role": "CASE_MANAGER"}	\N	2026-07-08 17:14:24	f	\N	\N	127.0.0.1	Symfony	b9369275-185d-4f10-b148-a4ca320e9337	\N
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: case_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_categories (id, name, description, color, sort_order, is_active, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_documents (id, file_name, file_path, file_type, size, case_id, user_id, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: case_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_issues (id, name, description, sort_order, is_active, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_notifications (id, case_id, client_email, type, title, message, data, related_url, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: case_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_statuses (id, name, slug, type, color, sort_order, is_system, is_active, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
13cccbd2-c63a-4734-8dce-6a0136b370fa	Open	OPEN	case	#22c55e	1	t	t	f	\N	\N	\N	\N
d20a5060-1b35-4862-9b7e-6570d70a1e5e	Closed	CLOSED	case	#64748b	2	t	t	f	\N	\N	\N	\N
16c7a768-8137-458f-b1db-36465636eb42	Pending	PENDING	referral	#f59e0b	1	t	t	f	\N	\N	\N	\N
576d2221-6dce-421d-8fb1-b0669952b363	Processing	PROCESSING	referral	#3b82f6	2	t	t	f	\N	\N	\N	\N
e75f2feb-c62c-4d84-a304-0388fa9bbb5e	For Compliance	FOR_COMPLIANCE	referral	#f97316	3	t	t	f	\N	\N	\N	\N
9c9e5271-2469-4c60-932b-cbcc8687d149	Completed	COMPLETED	referral	#22c55e	4	t	t	f	\N	\N	\N	\N
d1a6279f-f995-41f0-b073-29817f210126	Rejected	REJECTED	referral	#ef4444	5	t	t	f	\N	\N	\N	\N
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases (id, case_number, client_type, vulnerability_indicator, nok_vulnerability_indicator, tracker_number, summary, status, closed_at, consent_given_at, user_id, client_id, category_id, case_issue_id, draft_client_data, escalation_reason, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: client_addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_addresses (id, client_id, region, province, city_municipality, barangay, street, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: client_employments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_employments (id, client_id, employer_name, "position", last_position, country, last_country, start_date, end_date, date_of_arrival, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, first_name, last_name, middle_initial, suffix, date_of_birth, sex, email, contact_number, avatar_url, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, to_email, subject, mailable_type, status, job_uuid, error_message, sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, case_id, agency_id, referral_id, service_name, overall_rating, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feedback_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback_invitations (id, case_id, agency_id, referral_id, client_email, token_prefix, token_hash, service_name, snapshot_source, form_snapshot, rating_labels, expires_at, submitted_at, used_feedback_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feedback_servqual_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback_servqual_responses (id, feedback_id, question_id, question_text, dimension, expectation, perception, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_framework_tables	1
2	2026_06_01_000001_create_core_reference_tables	1
3	2026_06_01_000002_create_case_tables	1
4	2026_06_01_000003_create_referral_tables	1
5	2026_06_01_000004_create_feedback_tables	1
6	2026_06_01_000006_create_monitoring_tables	1
7	2026_06_01_000007_enable_extensions	1
8	2026_06_01_000008_enable_row_level_security	1
9	2026_06_02_000001_rls_policies_remaining_tables	1
10	2026_06_21_112449_convert_address_codes_to_names	1
11	2026_07_02_074905_drop_case_comments_table	1
12	2026_07_03_000001_drop_type_from_referrals	1
13	2026_07_03_000002_rename_client_middle_name_to_middle_initial	1
14	2026_07_04_000001_create_feedback_invitations_table	1
15	2026_07_04_000001_improve_audit_logs_table	1
16	2026_07_08_000001_drop_philippine_addresses_table	1
17	2026_07_08_000002_drop_escalated_at_from_cases	1
18	2026_07_08_000002_make_audit_logs_trigger_conditional	1
19	2026_07_09_000001_encrypt_pii_fields	1
\.


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.milestones (id, title, description, refr_id, user_id, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: next_of_kin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.next_of_kin (id, client_id, first_name, last_name, middle_initial, relationship, is_primary, phone_number, email, full_address, region, province, city_municipality, barangay, street, sort_order, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, type, notifiable_id, notifiable_type, data, read_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: referral_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referral_attachments (id, referral_id, file_name, file_path, file_type, size, user_id, replaces_id, version_group_id, is_archived, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: referral_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referral_comments (id, refr_id, parent_id, content, visibility, is_edited, user_id, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: referral_compliance_requirements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referral_compliance_requirements (id, referral_id, service_name, requirement_name, status, fulfilled_by, completed_at, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referrals (id, required_services, notes, status, decision, decision_comment, case_id, agcy_id, first_action_at, referral_assigned_at, created_at, updated_at, is_deleted, deleted_at, deleted_by) FROM stdin;
\.


--
-- Data for Name: service_requirements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_requirements (id, name, description, is_required, service_id, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, name, description, agcy_id, processing_days, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: servqual_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.servqual_configs (id, agency_id, service_name, questions, created_at, updated_at, is_active, activated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (key, category, value, description, created_at, updated_at) FROM stdin;
debug_otp_enabled	\N	false	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password, role, agcy_id, is_active, contact_number, avatar_url, "position", department, office_location, bio, emergency_contact, timezone, mfa_secret, mfa_recovery_codes, mfa_enabled_at, notifications_config, onboarding_completed_at, onboarding_step, profile_completed_at, email_verified_at, remember_token, is_deleted, deleted_at, deleted_by, created_at, updated_at) FROM stdin;
2c090aca-d491-42c8-858e-0d474514e356	Elmira Nicolas III	jackson.stokes@example.net	$2y$04$U0dc5nYvdCD6NKuh0hjWIe9ca3U/3odAQut3znUQyHUWqtHBxEqEu	CASE_MANAGER	\N	t	+1 (332) 645-6449	\N	\N	\N	\N	\N	\N	Asia/Manila	\N	\N	\N	\N	\N	\N	\N	2026-07-08 17:14:24	xWXGCJMwgD	f	\N	\N	2026-07-08 17:14:24	2026-07-08 17:14:24
\.


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 2, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 19, true);


--
-- Name: agencies agencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_pkey PRIMARY KEY (id);


--
-- Name: agencies agencies_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_slug_unique UNIQUE (slug);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: case_categories case_categories_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_categories
    ADD CONSTRAINT case_categories_name_unique UNIQUE (name);


--
-- Name: case_categories case_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_categories
    ADD CONSTRAINT case_categories_pkey PRIMARY KEY (id);


--
-- Name: case_documents case_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_documents
    ADD CONSTRAINT case_documents_pkey PRIMARY KEY (id);


--
-- Name: case_issues case_issues_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_issues
    ADD CONSTRAINT case_issues_name_unique UNIQUE (name);


--
-- Name: case_issues case_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_issues
    ADD CONSTRAINT case_issues_pkey PRIMARY KEY (id);


--
-- Name: case_notifications case_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_notifications
    ADD CONSTRAINT case_notifications_pkey PRIMARY KEY (id);


--
-- Name: case_statuses case_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_statuses
    ADD CONSTRAINT case_statuses_pkey PRIMARY KEY (id);


--
-- Name: case_statuses case_statuses_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_statuses
    ADD CONSTRAINT case_statuses_slug_unique UNIQUE (slug);


--
-- Name: cases cases_case_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_case_number_unique UNIQUE (case_number);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (id);


--
-- Name: cases cases_tracker_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_tracker_number_unique UNIQUE (tracker_number);


--
-- Name: client_addresses client_addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_pkey PRIMARY KEY (id);


--
-- Name: client_employments client_employments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_employments
    ADD CONSTRAINT client_employments_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: feedback feedback_case_agency_referral_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_case_agency_referral_unique UNIQUE (case_id, agency_id, referral_id);


--
-- Name: feedback_invitations feedback_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_pkey PRIMARY KEY (id);


--
-- Name: feedback_invitations feedback_invitations_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_unique UNIQUE (case_id, agency_id, referral_id);


--
-- Name: feedback_invitations feedback_invitations_used_feedback_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_used_feedback_id_unique UNIQUE (used_feedback_id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: feedback_servqual_responses feedback_servqual_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_servqual_responses
    ADD CONSTRAINT feedback_servqual_responses_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: milestones milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: next_of_kin next_of_kin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.next_of_kin
    ADD CONSTRAINT next_of_kin_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: referral_attachments referral_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_attachments
    ADD CONSTRAINT referral_attachments_pkey PRIMARY KEY (id);


--
-- Name: referral_comments referral_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_pkey PRIMARY KEY (id);


--
-- Name: referral_compliance_requirements referral_compliance_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_compliance_requirements
    ADD CONSTRAINT referral_compliance_requirements_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: service_requirements service_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requirements
    ADD CONSTRAINT service_requirements_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: servqual_configs servqual_configs_agency_id_service_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servqual_configs
    ADD CONSTRAINT servqual_configs_agency_id_service_name_unique UNIQUE (agency_id, service_name);


--
-- Name: servqual_configs servqual_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servqual_configs
    ADD CONSTRAINT servqual_configs_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: case_notifications_case_id_client_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX case_notifications_case_id_client_email_index ON public.case_notifications USING btree (case_id, client_email);


--
-- Name: case_notifications_read_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX case_notifications_read_at_index ON public.case_notifications USING btree (read_at);


--
-- Name: feedback_invitations_token_prefix_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX feedback_invitations_token_prefix_idx ON public.feedback_invitations USING btree (token_prefix);


--
-- Name: idx_audit_logs_action_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action_time ON public.audit_logs USING btree (action, "timestamp" DESC);


--
-- Name: idx_audit_logs_description_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_description_trgm ON public.audit_logs USING gin (description public.gin_trgm_ops);


--
-- Name: idx_audit_logs_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity_id ON public.audit_logs USING btree (entity_id);


--
-- Name: idx_audit_logs_entity_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_entity_lookup ON public.audit_logs USING btree (module, entity_id, "timestamp" DESC);


--
-- Name: idx_audit_logs_new_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_new_value ON public.audit_logs USING gin (new_value jsonb_path_ops);


--
-- Name: idx_audit_logs_old_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_old_value ON public.audit_logs USING gin (old_value jsonb_path_ops);


--
-- Name: idx_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_timestamp ON public.audit_logs USING btree ("timestamp" DESC);


--
-- Name: idx_audit_logs_user_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user_action ON public.audit_logs USING btree (user_id, action, "timestamp" DESC);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: notifications_notifiable_id_notifiable_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_notifiable_id_notifiable_type_index ON public.notifications USING btree (notifiable_id, notifiable_type);


--
-- Name: referral_compliance_requirements_referral_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX referral_compliance_requirements_referral_id_status_index ON public.referral_compliance_requirements USING btree (referral_id, status);


--
-- Name: referral_compliance_requirements_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX referral_compliance_requirements_status_index ON public.referral_compliance_requirements USING btree (status);


--
-- Name: servqual_configs_active_agency_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX servqual_configs_active_agency_unique ON public.servqual_configs USING btree (agency_id) WHERE (is_active = true);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: audit_logs trg_audit_logs_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_logs_append_only BEFORE DELETE OR UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.block_audit_log_modification();


--
-- Name: agencies agencies_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: audit_logs audit_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_categories case_categories_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_categories
    ADD CONSTRAINT case_categories_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_documents case_documents_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_documents
    ADD CONSTRAINT case_documents_case_id_foreign FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE RESTRICT;


--
-- Name: case_documents case_documents_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_documents
    ADD CONSTRAINT case_documents_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_documents case_documents_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_documents
    ADD CONSTRAINT case_documents_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_issues case_issues_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_issues
    ADD CONSTRAINT case_issues_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_notifications case_notifications_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_notifications
    ADD CONSTRAINT case_notifications_case_id_foreign FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_statuses case_statuses_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_statuses
    ADD CONSTRAINT case_statuses_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: cases cases_case_issue_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_case_issue_id_foreign FOREIGN KEY (case_issue_id) REFERENCES public.case_issues(id) ON DELETE SET NULL;


--
-- Name: cases cases_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.case_categories(id) ON DELETE RESTRICT;


--
-- Name: cases cases_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: cases cases_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: cases cases_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: client_addresses client_addresses_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: client_addresses client_addresses_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_addresses
    ADD CONSTRAINT client_addresses_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: client_employments client_employments_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_employments
    ADD CONSTRAINT client_employments_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: client_employments client_employments_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_employments
    ADD CONSTRAINT client_employments_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: clients clients_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: feedback feedback_agency_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_agency_id_foreign FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE RESTRICT;


--
-- Name: feedback feedback_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_case_id_foreign FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE RESTRICT;


--
-- Name: feedback_invitations feedback_invitations_agency_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_agency_id_foreign FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE RESTRICT;


--
-- Name: feedback_invitations feedback_invitations_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_case_id_foreign FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE RESTRICT;


--
-- Name: feedback_invitations feedback_invitations_referral_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_referral_id_foreign FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE SET NULL;


--
-- Name: feedback_invitations feedback_invitations_used_feedback_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_invitations
    ADD CONSTRAINT feedback_invitations_used_feedback_id_foreign FOREIGN KEY (used_feedback_id) REFERENCES public.feedback(id) ON DELETE SET NULL;


--
-- Name: feedback feedback_referral_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_referral_id_foreign FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE SET NULL;


--
-- Name: feedback_servqual_responses feedback_servqual_responses_feedback_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback_servqual_responses
    ADD CONSTRAINT feedback_servqual_responses_feedback_id_foreign FOREIGN KEY (feedback_id) REFERENCES public.feedback(id) ON DELETE CASCADE;


--
-- Name: milestones milestones_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: milestones milestones_refr_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_refr_id_foreign FOREIGN KEY (refr_id) REFERENCES public.referrals(id) ON DELETE RESTRICT;


--
-- Name: milestones milestones_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.milestones
    ADD CONSTRAINT milestones_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: next_of_kin next_of_kin_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.next_of_kin
    ADD CONSTRAINT next_of_kin_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: next_of_kin next_of_kin_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.next_of_kin
    ADD CONSTRAINT next_of_kin_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: referral_attachments referral_attachments_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_attachments
    ADD CONSTRAINT referral_attachments_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: referral_attachments referral_attachments_referral_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_attachments
    ADD CONSTRAINT referral_attachments_referral_id_foreign FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE RESTRICT;


--
-- Name: referral_attachments referral_attachments_replaces_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_attachments
    ADD CONSTRAINT referral_attachments_replaces_id_foreign FOREIGN KEY (replaces_id) REFERENCES public.referral_attachments(id) ON DELETE SET NULL;


--
-- Name: referral_attachments referral_attachments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_attachments
    ADD CONSTRAINT referral_attachments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: referral_comments referral_comments_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: referral_comments referral_comments_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.referral_comments(id) ON DELETE RESTRICT;


--
-- Name: referral_comments referral_comments_refr_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_refr_id_foreign FOREIGN KEY (refr_id) REFERENCES public.referrals(id) ON DELETE RESTRICT;


--
-- Name: referral_comments referral_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: referral_compliance_requirements referral_compliance_requirements_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_compliance_requirements
    ADD CONSTRAINT referral_compliance_requirements_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: referral_compliance_requirements referral_compliance_requirements_fulfilled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_compliance_requirements
    ADD CONSTRAINT referral_compliance_requirements_fulfilled_by_foreign FOREIGN KEY (fulfilled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: referral_compliance_requirements referral_compliance_requirements_referral_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_compliance_requirements
    ADD CONSTRAINT referral_compliance_requirements_referral_id_foreign FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE RESTRICT;


--
-- Name: referrals referrals_agcy_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_agcy_id_foreign FOREIGN KEY (agcy_id) REFERENCES public.agencies(id) ON DELETE RESTRICT;


--
-- Name: referrals referrals_case_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_case_id_foreign FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE RESTRICT;


--
-- Name: referrals referrals_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: service_requirements service_requirements_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requirements
    ADD CONSTRAINT service_requirements_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: service_requirements service_requirements_service_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_requirements
    ADD CONSTRAINT service_requirements_service_id_foreign FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE RESTRICT;


--
-- Name: services services_agcy_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_agcy_id_foreign FOREIGN KEY (agcy_id) REFERENCES public.agencies(id) ON DELETE RESTRICT;


--
-- Name: services services_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: servqual_configs servqual_configs_agency_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.servqual_configs
    ADD CONSTRAINT servqual_configs_agency_id_foreign FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON DELETE RESTRICT;


--
-- Name: users users_agcy_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_agcy_id_foreign FOREIGN KEY (agcy_id) REFERENCES public.agencies(id) ON DELETE RESTRICT;


--
-- Name: users users_deleted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_deleted_by_foreign FOREIGN KEY (deleted_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: case_documents admin_all_case_documents; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_case_documents ON public.case_documents USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: case_notifications admin_all_case_notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_case_notifications ON public.case_notifications USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: cases admin_all_cases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_cases ON public.cases USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: client_addresses admin_all_client_addresses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_client_addresses ON public.client_addresses USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: client_employments admin_all_client_employments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_client_employments ON public.client_employments USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: clients admin_all_clients; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_clients ON public.clients USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: milestones admin_all_milestones; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_milestones ON public.milestones USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: next_of_kin admin_all_next_of_kin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_next_of_kin ON public.next_of_kin USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: referral_attachments admin_all_referral_attachments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_referral_attachments ON public.referral_attachments USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: referral_comments admin_all_referral_comments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_referral_comments ON public.referral_comments USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: referrals admin_all_referrals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY admin_all_referrals ON public.referrals USING ((current_setting('app.user_role'::text, true) = 'ADMIN'::text)) WITH CHECK ((current_setting('app.user_role'::text, true) = 'ADMIN'::text));


--
-- Name: cases agency_referred_cases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agency_referred_cases ON public.cases USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (id IN ( SELECT r.case_id
   FROM public.referrals r
  WHERE (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid)))))));


--
-- Name: case_documents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.case_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: case_documents case_documents_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY case_documents_agency_referred ON public.case_documents USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM (public.cases c
     JOIN public.referrals r ON ((r.case_id = c.id)))
  WHERE ((c.id = r.case_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: case_documents case_documents_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY case_documents_case_manager_own ON public.case_documents USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM public.cases c
  WHERE ((c.id = case_documents.case_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: cases case_manager_own_cases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY case_manager_own_cases ON public.cases USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (user_id = (current_setting('app.current_user_id'::text, true))::uuid)));


--
-- Name: case_notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.case_notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: case_notifications case_notifications_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY case_notifications_agency_referred ON public.case_notifications USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM (public.cases c
     JOIN public.referrals r ON ((r.case_id = c.id)))
  WHERE ((c.id = r.case_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: case_notifications case_notifications_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY case_notifications_case_manager_own ON public.case_notifications USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM public.cases c
  WHERE ((c.id = case_notifications.case_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: cases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY;

--
-- Name: client_addresses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_addresses ENABLE ROW LEVEL SECURITY;

--
-- Name: client_addresses client_addresses_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY client_addresses_agency_referred ON public.client_addresses USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM ((public.clients cl
     JOIN public.cases c ON ((c.client_id = cl.id)))
     JOIN public.referrals r ON ((r.case_id = c.id)))
  WHERE ((cl.id = c.client_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: client_addresses client_addresses_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY client_addresses_case_manager_own ON public.client_addresses USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM (public.clients cl
     JOIN public.cases c ON ((c.client_id = cl.id)))
  WHERE ((cl.id = c.client_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: client_employments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_employments ENABLE ROW LEVEL SECURITY;

--
-- Name: client_employments client_employments_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY client_employments_agency_referred ON public.client_employments USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM ((public.clients cl
     JOIN public.cases c ON ((c.client_id = cl.id)))
     JOIN public.referrals r ON ((r.case_id = c.id)))
  WHERE ((cl.id = c.client_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: client_employments client_employments_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY client_employments_case_manager_own ON public.client_employments USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM (public.clients cl
     JOIN public.cases c ON ((c.client_id = cl.id)))
  WHERE ((cl.id = c.client_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: clients clients_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clients_agency_referred ON public.clients USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM (public.cases c
     JOIN public.referrals r ON ((r.case_id = c.id)))
  WHERE ((c.client_id = clients.id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: clients clients_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clients_case_manager_own ON public.clients USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM public.cases c
  WHERE ((c.client_id = clients.id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: milestones; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.milestones ENABLE ROW LEVEL SECURITY;

--
-- Name: milestones milestones_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY milestones_agency_referred ON public.milestones USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM public.referrals r
  WHERE ((r.id = milestones.refr_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: milestones milestones_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY milestones_case_manager_own ON public.milestones USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM (public.referrals r
     JOIN public.cases c ON ((c.id = r.case_id)))
  WHERE ((r.id = milestones.refr_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: next_of_kin; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.next_of_kin ENABLE ROW LEVEL SECURITY;

--
-- Name: next_of_kin next_of_kin_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY next_of_kin_agency_referred ON public.next_of_kin USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM ((public.clients cl
     JOIN public.cases c ON ((c.client_id = cl.id)))
     JOIN public.referrals r ON ((r.case_id = c.id)))
  WHERE ((cl.id = c.client_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: next_of_kin next_of_kin_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY next_of_kin_case_manager_own ON public.next_of_kin USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM (public.clients cl
     JOIN public.cases c ON ((c.client_id = cl.id)))
  WHERE ((cl.id = c.client_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: referral_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.referral_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: referral_attachments referral_attachments_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY referral_attachments_agency_referred ON public.referral_attachments USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM public.referrals r
  WHERE ((r.id = referral_attachments.referral_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: referral_attachments referral_attachments_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY referral_attachments_case_manager_own ON public.referral_attachments USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM (public.referrals r
     JOIN public.cases c ON ((c.id = r.case_id)))
  WHERE ((r.id = referral_attachments.referral_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: referral_comments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.referral_comments ENABLE ROW LEVEL SECURITY;

--
-- Name: referral_comments referral_comments_agency_referred; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY referral_comments_agency_referred ON public.referral_comments USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (EXISTS ( SELECT 1
   FROM public.referrals r
  WHERE ((r.id = referral_comments.refr_id) AND (r.agcy_id = ( SELECT u.agcy_id
           FROM public.users u
          WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid))))))));


--
-- Name: referral_comments referral_comments_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY referral_comments_case_manager_own ON public.referral_comments USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM (public.referrals r
     JOIN public.cases c ON ((c.id = r.case_id)))
  WHERE ((r.id = referral_comments.refr_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- Name: referrals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

--
-- Name: referrals referrals_agency_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY referrals_agency_own ON public.referrals USING (((current_setting('app.user_role'::text, true) = 'AGENCY'::text) AND (agcy_id = ( SELECT u.agcy_id
   FROM public.users u
  WHERE (u.id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: referrals referrals_case_manager_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY referrals_case_manager_own ON public.referrals USING (((current_setting('app.user_role'::text, true) = 'CASE_MANAGER'::text) AND (EXISTS ( SELECT 1
   FROM public.cases c
  WHERE ((c.id = referrals.case_id) AND (c.user_id = (current_setting('app.current_user_id'::text, true))::uuid))))));


--
-- PostgreSQL database dump complete
--

